# Lib: Realm Info

## [17](https://github.com/janekjl/LibRealmInfo/tree/14) (2021-01-21)
[Full Changelog](https://github.com/janekjl/LibRealmInfo/compare/14...17)

- China Realm information added.
- 2020 Connections added and server properties updated where applicable.
- Added Classic Realm data
- Typo fixes for 2 realm names