if not LOCALE_zhTW then return end

local L = select( 2, ...).L

L["ENHANCED_MENU"] = "增強菜單"
L["GUILD_INVITE"] = "邀請入會"
L["COPY_NAME"] = "複製名字"
L["SEND_WHO"] = "查詢"
L["ARMORY_URL"] = "英雄榜"
L["FRIEND_ADD"] = "Add Friend"
