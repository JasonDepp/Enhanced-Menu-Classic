-- by Durcc
if not LOCALE_esES then return end

local L = select( 2, ...).L

L["ENHANCED_MENU"] = "Enhanced Menu"
L["GUILD_INVITE"] = "Invitar a la Hermandad"
L["COPY_NAME"] = "Copiar Nombre"
L["SEND_WHO"] = "¿Quién?"
L["ARMORY_URL"] = "Armería"
L["FRIEND_ADD"] = "Add Friend"
