-- by Sexnonstop
if not LOCALE_ruRU then return end

local L = select( 2, ...).L

L["ENHANCED_MENU"] = "Улучшенное Меню:"
L["GUILD_INVITE"] = "Пригласить в Гильдию"
L["COPY_NAME"] = "Cкопировать никнейм"
L["SEND_WHO"] = "Информация"
L["ARMORY_URL"] = "Ссылка в Оружейной"
L["FRIEND_ADD"] = "Add Friend"
