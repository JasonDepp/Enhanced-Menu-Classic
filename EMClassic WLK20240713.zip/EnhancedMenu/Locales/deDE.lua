-- by pas06
if not LOCALE_deDE then return end

local L = select( 2, ...).L

L["ENHANCED_MENU"] = "Enhanced Menu"
L["GUILD_INVITE"] = "Gildeneinladung"
L["COPY_NAME"] = "Namen kopieren"
L["SEND_WHO"] = "Wer"
L["ARMORY_URL"] = "Armory"
L["FRIEND_ADD"] = "Add Friend"
