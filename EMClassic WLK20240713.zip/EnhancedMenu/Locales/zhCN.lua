if not LOCALE_zhCN then return end

local L = select( 2, ...).L

L["ENHANCED_MENU"] = "增强菜单"
L["SEND_WHO"] = "查询玩家"
L["COPY_NAME"] = "获取名字"
L["GUILD_INVITE"] = "公会邀请"
L["ARMORY_URL"] = "英雄榜"
L["FRIEND_ADD"] = "添加好友"
